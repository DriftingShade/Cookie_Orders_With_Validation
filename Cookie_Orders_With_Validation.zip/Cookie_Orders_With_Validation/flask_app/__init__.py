from flask import Flask, session

app = Flask(__name__)
app.secret_key = "*/456/915650/898/8easnkvflookimhidingdasve/a8v*9r/g0ava/8sas/8a0"
